function validasi() {
    var nama = document.getElementById("nama").value;
    var email = document.getElementById("email").value;
    var alamat = document.getElementById("pesan").value;
    if (nama != "" && email != "" && alamat != "" && pesan != "") {
        var yakin = confirm("Apakah anda yakin akan mengirimkan pesan ini ?");
        if (yakin) {
            alert("selamat pesan anda telah direkam");
            return true;
        } else {
            alert('Data anda gagal direkam !');
        }
    } else {
        alert('Anda harus mengisi data dengan lengkap !');
    }
}

